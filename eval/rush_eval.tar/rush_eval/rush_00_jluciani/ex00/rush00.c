/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   rush00.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jluciani <jluciani@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/01/14 16:59:04 by jluciani          #+#    #+#             */
/*   Updated: 2024/01/15 17:24:12 by mobin-mu         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

void	ft_putchar(char c);

void	patern_line(int i, int j, int x, int y)
{
	if ((i == 1 && j == 1) || (i == 1 && j == y))
		ft_putchar('o');
	else if ((i == x && j == 1) || (i == x && j == y))
		ft_putchar('o');
	else if ((i > 1 && i < x && j == 1) || (i > 1 && i < x && j == y))
		ft_putchar('-');
	else if (j > 1 && j < y && i == 1)
		ft_putchar('|');
	else if (j > 1 && j < y && i == x)
		ft_putchar('|');
	else
		ft_putchar(' ');
}

void	rush(int x, int y)
{
	int	i;
	int	j;

	i = 1;
	j = 1;
	while (j <= y)
	{
		while (i <= x)
		{
			patern_line(i, j, x, y);
			i++;
		}
		ft_putchar('\n');
		i = 1;
		j++;
	}
}
