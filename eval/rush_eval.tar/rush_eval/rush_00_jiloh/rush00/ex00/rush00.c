/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   rush00.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jiloh <jiloh@student.42kl.edu.my>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/01/13 15:18:33 by jiloh             #+#    #+#             */
/*   Updated: 2024/01/14 17:21:34 by chtan            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include <unistd.h>

void	ft_putchar(char c);

void	rush(int x, int y)
{
	int	row;
	int	column;

	row = 1;
	while (row <= y)
	{
		column = 1;
		while (column <= x)
		{
			if ((row == 1 || row == y) && (column == 1 || column == x))
				ft_putchar('o');
			else if ((row == 1 || row == y) && column > 1 && column < x)
				ft_putchar('-');
			else if (row > 1 && row < y && (column == 1 || column == x))
				ft_putchar('|');
			else if (row > 1 && row < y && column > 1 && column < x)
				ft_putchar(' ');
			column++;
		}
		row++;
		if (x > 0)
			ft_putchar('\n');
	}
}
