/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mobin-mu <mobin-mu@student.42kl.edu.my>    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/01/13 16:22:46 by asarpan           #+#    #+#             */
/*   Updated: 2024/01/15 16:49:03 by mobin-mu         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <limits.h>

void	ft_putchar(char c);
void	rush(int x, int y);

int	main(int argc, char **argv)
{
	rush (argv[1][0], argv[2][0]);
	return (0);
}
