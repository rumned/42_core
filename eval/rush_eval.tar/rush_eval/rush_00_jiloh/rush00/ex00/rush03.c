/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   rush03.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: chtan <chtan@student.42kl.edu.my>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/01/14 12:24:47 by chtan             #+#    #+#             */
/*   Updated: 2024/01/14 12:25:29 by chtan            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

void	ft_putchar(char c);

void	ft_print_character(int x, int y, int row, int column)
{
	if (row == 1 && column == 1)
		ft_putchar('A');
	else if ((row == 1 || row == y) && column > 1 && column < x)
		ft_putchar('B');
	else if (row == 1 && column == x)
		ft_putchar('C');
	else if (row > 1 && row < y && (column == 1 || column == x))
		ft_putchar('B');
	else if (row > 1 && row < y && column > 1 && column < x)
		ft_putchar(' ');
	else if (row == y && column == 1)
		ft_putchar('A');
	else if (row == y && column == x)
		ft_putchar('C');
}

void	rush(int x, int y)
{
	int	row;
	int	column;

	row = 1;
	while (row <= y)
	{
		column = 1;
		while (column <= x)
		{
			ft_print_character(x, y, row, column);
			column++;
		}
		row++;
		if (x > 0)
			ft_putchar('\n');
	}
}
